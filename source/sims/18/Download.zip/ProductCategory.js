var ProductCategory = new cLASS( {
  Name: "ProductCategory",
  supertypeName: "oBJECT",
  properties: {
    "market": {range: "DailyDemandMarket", label: "Daily demand market"}
  }
} );