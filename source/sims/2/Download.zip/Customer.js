var Customer = new cLASS({
  Name: "Customer",
  shortLabel: "Cust",
  supertypeName: "oBJECT",
  properties: {
    "arrivalTime": { range: "Decimal", label: "Arrival time",
        shortLabel: "arrT"}
  }
});
