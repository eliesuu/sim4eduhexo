/*******************************************************
 * FourConsecutiveMachines-3 - An example of a discrete event simulation.
 *
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
sim.scenario.simulationEndTime = 100;
sim.scenario.idCounter = 11;  // start value of auto IDs
sim.scenario.randomSeed = 2345;  // optional
sim.config.createLog = false;
//sim.config.suppressInitialStateUI = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.time = "continuous";
sim.model.timeRoundingDecimalPlaces = 1;  // like in 3.8

// fixed model parameters
sim.model.v.revenuePerOrder = 15;
sim.model.v.backlogCostsPerOrderPerTimeUnit = 0.1;
// variable model parameters
sim.model.v.manuCostsPerOrder = 11;
sim.model.v.orderEventRate = 0.75;

/*******************************************************
 Define Initial State
********************************************************/
sim.scenario.initialState.objects = {
  "1": {typeName: "eNTRYnODE", name:"orderEntry", successorNode: 2,
        arrivalRecurrence: function () { return rand.exponential( sim.model.v.orderEventRate);}},
  "2": {typeName: "pROCESSINGnODE", name:"M1", successorNode: 3,
        randomDuration: function () { return rand.triangular(0.5, 1, 1.5);}},
  "3": {typeName: "pROCESSINGnODE", name:"M2", successorNode: 4,
        randomDuration: function () { return rand.triangular(0.5, 1, 1.5);}},
  "4": {typeName: "pROCESSINGnODE", name:"M3", successorNode: 5,
        randomDuration: function () { return rand.triangular(1, 1.5, 2);}},
  "5": {typeName: "pROCESSINGnODE", name:"M4", successorNode: 6,
        randomDuration: function () { return rand.triangular(0.5, 1, 1.5);}},
  "6": {typeName: "eXITnODE", name:"orderExit",
        onDeparture: function () {
          var backlogQuantity = sim.stat.arrivedOrders - sim.stat.departedOrders;
          sim.stat.revenue += sim.model.v.revenuePerOrder;
          sim.stat.manuCosts += sim.model.v.manuCostsPerOrder;
          sim.stat.backlogCosts += sim.model.v.backlogCostsPerOrderPerTimeUnit * backlogQuantity;
          return [];
        }}
};
/*******************************************************
 Define Output Statistics Variables
 ********************************************************/
sim.model.statistics = {
  "arrivedOrders": {objectType:"eNTRYnODE", objectIdRef: 1, property:"nmrOfArrivedObjects"},
  "departedOrders": {objectType:"eXITnODE", objectIdRef: 6, property:"nmrOfDepartedObjects"},
  "revenue": {range:"Decimal", label:"Revenue", unit: "T€"},
  "manuCosts": {range:"Decimal", label:"Manuf. costs", unit: "T€"},
  "backlogCosts": {range:"Decimal", label:"Backlog costs", unit: "T€"},
  "profit": { range: "Decimal",  label:"Profit",
    computeOnlyAtEnd: true, decimalPlaces: 1, unit: "T€",
    expression: function () {
      return sim.stat.revenue - (sim.stat.manuCosts + sim.stat.backlogCosts)}
  }
};
