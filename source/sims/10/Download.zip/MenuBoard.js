var MenuBoard = new cLASS({
  Name: "MenuBoard",
  supertypeName: "oBJECT",
  properties: {
    "waitingCustomers": { range: "Customer", label: "Waiting customers",
        shortLabel: "waitCust", minCard: 0, maxCard: Infinity},
    "maxLineSize": { range: "NonNegativeInteger", label: "Queue length limit"},
    "kitchen": { range: "Kitchen"},
    "pickupWindow": { range: "PickupWindow"},
    "isBlocked": { range: "Boolean", optional: true, shortLabel: "blocked"}
  }
});
