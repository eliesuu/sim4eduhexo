/*******************************************************************************
 * The Reception activity class
 *
 * @copyright Copyright 2015-2016 Gerd Wagner
 *   Chair of Internet Technology, Brandenburg University of Technology, Germany.
 * @license The MIT License (MIT)
 * @author Gerd Wagner
 ******************************************************************************/

/**
 * @type {cLASS}
 *
 * When a new Reception JS object is created via the CustomerArrival event rule
 * scheduling an ActivityStart event with a resource allocation {"serviceDesk": this.serviceDesk},
 * a corresponding "serviceDesk" property slot is created. Consequently, the expression
 * "this.serviceDesk" can be used for accessing the associated serviceDesk object.
 */

var OrderPickup = new cLASS({
  Name: "OrderPickup",
  shortLabel: "OrdPick",
  supertypeName: "aCTIVITY",
  // resource roles are special reference properties
  resourceRoles: {"pickupWindow": {range:"PickupWindow", exclusive: true}},
  properties: {},  // there are no additional properties
  methods: {
    // event rule for ActivityStart
    "onActivityStart": function () {
      var followupEvents = [],
          nextCustomer = this.pickupWindow.waitingCustomers[0];
      // check if the customer's order is not yet available?
      if (!this.pickupWindow.preparedOrders.includes(nextCustomer.id) ) {
        // suspend activity by resetting its duration to zero
        this.duration = 0;
        this.pickupWindow.suspendedActivityId = this.id;
      }
      return followupEvents;
    },
    // event rule for ActivityEnd
    "onActivityEnd": function () {
      var followupEvents = [], orderNo = 0, customer=null;
      // remove order from queue
      orderNo = this.pickupWindow.preparedOrders.shift();
      // remove customer from queue
      customer = this.pickupWindow.waitingCustomers.shift();
      // remove customer from simulation
      sim.removeObject( customer);
      // update departedCustomers statistics
      sim.stat.departedCustomers++;
      //
      sim.stat.cumulativeTimeInSystem += sim.time - customer.arrivalTime;
      // if there are still customers waiting
      if (this.pickupWindow.waitingCustomers.length > 0) {
        // if menu board has been blocked due to a full pickup queue?
        if (this.pickupWindow.waitingCustomers.length === 2 &&
            this.pickupWindow.menuBoard.isBlocked) {
          // remove next customer from menu board queue
          customer = this.pickupWindow.menuBoard.waitingCustomers.shift();
          // add customer to the pickup window queue
          this.pickupWindow.waitingCustomers.push( customer);
          // if there are still customers waiting at the menu board?
          if (this.pickupWindow.menuBoard.waitingCustomers.length > 0) {
            // schedule next OrderTaking activity
            followupEvents.push( new oes.ActivityStart({
              occTime: sim.time + 1,
              activityType: "OrderTaking",
              // define resource roles (s.th. corresp. activity properties will be created)
              resources: {"menuBoard": this.pickupWindow.menuBoard}
            }));
          }
          delete this.pickupWindow.menuBoard.isBlocked;  // unset flag
        }
        // schedule next OrderPickup activity start event
        followupEvents.push( new oes.ActivityStart({
          occTime: sim.time + 1,
          activityType: "OrderPickup",
          // define resource roles (s.th. corresp. activity properties will be created)
          resources: {"pickupWindow": this.pickupWindow}
        }));
      }
      return followupEvents;
    }
  }
});

OrderPickup.randomDuration = function () {
  return sim.model.f.twoDice() * 10;
};
