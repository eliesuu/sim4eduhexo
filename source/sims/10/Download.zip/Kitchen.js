var Kitchen = new cLASS({
  Name: "Kitchen",
  supertypeName: "oBJECT",
  properties: {
    "waitingOrders": { range: "Integer", label: "Waiting Orders",
        shortLabel: "waitOrd", minCard: 0, maxCard: Infinity},
    "pickupWindow": { range: "PickupWindow"}
  }
});
